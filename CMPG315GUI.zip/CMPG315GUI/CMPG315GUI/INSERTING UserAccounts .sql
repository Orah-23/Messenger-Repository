﻿INSERT INTO tblUserAccount (UserName, Cellphone_No)
VALUES 
    ('Mhlengi', '0655536145'),
    ('Temog', '0123456789'),
    ('Tham', '1111111111'),
    ('CRock', '2222222222'),
    ('Quee', '3333333333');